# Version-1 complete-game import fixture

The Developer Kit includes `dots-and-squares-campaign-v1.zip`, generated from
this campaign document and the compiled default theme metadata. It contains
only `theme.json`, `campaign.json`, and a required PNG logo. The manifest binds
the campaign and media bytes by SHA-256 and declares Project/Author credits,
Theme SDK 0.2.0, and the registered `dots-and-squares@1.0.0` adapter.

The fixture intentionally contains two levels and connected sections with an
exit to a safe start. It is an import/conformance sample, not a claim that the
current multiplayer lifecycle executes campaign exits or transitions. Custom
code is never included in the ZIP.
