# Public API and sample settings

This kit uses engine API major 1 and packages built at the revision in
`kit.json`; the public Theme SDK version is 0.2.0. Full declarations ship in
each package's `dist\*.d.ts`.
Import only package exports, never engine/server/client checkout paths.

| Import | Contract |
| --- | --- |
| `@multiplayer-game/local-preview` | `createLocalGame(options)`, `mountLocalPreview(root, game, skinFactory, options?)` and their types |
| `@multiplayer-game/theme-sdk` | `GameModuleFactory`, `ModuleContext`, `SkinFactory`, `SkinHost`, map schemas/validation, movement controller, radar and setting validators |
| `@multiplayer-game/theme-sdk/package` | Node-only credits/manifest/asset schemas, SHA-256 helpers, canonical digest and asset mapping validation used by the existing exporter |
| `@multiplayer-game/protocol` | JSON/wire schemas and validated engine settings; these do not automatically become sample gameplay settings |

`createLocalGame` takes a module factory, validated module settings, a validated
map (or factory `createInitialMap`), numeric seed, roster and viewer.
It initializes an isolated in-memory simulation. `sendInput(accountId, unknown)`
returns false for rejected input; `step()` advances one fixed 1/30-second tick
and returns snapshot/events/completion requests. `snapshot`, `tick`,
`subscribe(listener)` and `dispose()` provide state, observation and cleanup.
The mounted host routes skin intent to that module and renders snapshots;
the caller drives the tick timer and disposes both mount and game.
Skin metadata must match module ID/state version. Module code owns gameplay
and validation; no account, network, persistent session or trusted client
authority is supplied. Preview metrics are no-ops; completion requests are
returned to the caller, not production lobby finalization.

## Connected-section local worlds

The public Theme SDK exports `MapSectionDefinition`,
`ConnectedMapDefinitionSchema`, `validateConnectedMapDefinition`,
`resolveConnectedMapSpawns` and `qualifyConnectedMapReference`. Pass a validated
world through `createLocalGame({ world, ... })`; `world` and legacy `map` are
mutually exclusive. Existing `map` and module-created initial-map flows retain
their single-map behavior.

A connected world contains 1-16 uniquely identified sections at unique origins.
Each origin is a safe-integer multiple of 2048 pixels, including negative
coordinates. Each section retains the existing map cell size (32), local
dimension limit (64-2048), and per-section limits (4096 objects, 4096
collisions, 256 spawns). Aggregate limits remain 4096 objects, 4096 collisions
and 256 spawns across the world; the bounding navigation grid is limited to
1,000,000 cells. Section maps may have no local player starts, but the complete
world needs at least two unique global player starts and one walkable start per
local-preview roster member.

The runtime resolves authored start positions once as `section.origin + local
position`, exposes the validated definition as `ModuleContext.connectedMap`
and the frozen world-position starts as `ModuleContext.connectedMapSpawns`, and
keeps entity/snapshot coordinates in stable world space. Section-local
IDs remain unchanged; use `qualifyConnectedMapReference(sectionId, localId)`
for unambiguous world references. Geometry queries and circle movement operate
on the union of sections: shared edges are traversable, while gaps, holes,
obstacles and exposed outer edges block movement, including swept movement
across a seam. The lower-level `ModuleContext.maps` prepare/commit API remains
a whole-geometry replacement mechanism; it is not the connected-world API.

`examples\local-preview\src\connected-sections.js` is a public-package consumer
example. Run `node connected-sections.mjs` in the installed sample to exercise
movement from west to east and east to west across a negative-origin seam.

The sample's `src\main.js` shows the complete API composition.
`src\game.js` implements the module lifecycle and input validation;
`src\skin.js` implements the skin/HUD/controls lifecycle; `src\map.js` uses
public map validation. Do not rename module/skin metadata without also updating
`theme.json` and arranging owner registration for import.

## Supported sample settings

| Setting | Range/default | Behavior |
| --- | --- | --- |
| `moveDistance` (`src\settings.js`) | finite number > 0 and <= 32; default 4 | Distance per fixed tick before the sample source multiplier; validated by `sampleGameModule.validateSettings` |
| `facingMovementBlend` | finite 0-1, default 0.40 in the starter | Public `MovementController` shortest-angle steering, preserving analog magnitude; missing value retains unsteered legacy settings |
| `controlMode` | `keyboard-only`, `keyboard-mouse`, `game-controller`; default `keyboard-mouse` | Initial selection; the skin's selector switches input locally and clears held state |
| `SPEED_MULTIPLIER` (`src\game.js`) | editable source constant, initially 1 | Demonstrated edit to 2 doubles a clear one-tick move from 4 to 8; not an engine/lobby setting |
| seed (`src\main.js`) | 42 in the example | Reproducible local RNG seed |
| map (`src\map.js`) | public `MapDefinition` | Bounded One Wall geometry/spawns; use `validateMapDefinition` |

The module and skin currently both import the same authored map; edit that
file rather than substituting a different runtime map in `main.js` alone.
`theme.json` describes the sample's supported setting/default. When changing
settings, synchronize its documentation with module validation and
`src\settings.js`. The generic protocol's default-theme combat, NPC, wave,
health and terrain settings are **not implemented by this sample**.

## Standard controller adapter

`readStandardGamepad(navigator.getGamepads?.())` is a public Theme SDK export.
It selects the first connected standard-mapped pad, decodes left-stick axes
0/1 and right-stick axes 2/3 using the existing radial 0.15 deadzone with
rescaled partial magnitude, normalizes nonzero aim, and reads right trigger
button 7 (`pressed` or value >= 0.5). Status is `connected`, `disconnected`,
`unsupported`, `unavailable` or `invalid`; all nonconnected states return neutral
movement/fire. Consumers own focus, polling, last-facing retention and neutral
dispatch on disconnect/blur. It does not change keyboard or mouse bindings.
Apply `MovementController` separately in module simulation, not again in a skin.
The default theme and sample reuse this adapter. Physical hardware is not
verified by simulated browser input.

## Export API boundary

`ThemeCreditsSchema` requires nonblank `project` and public `author`, with
optional string `course`. Exact errors are:

```text
Project (project) is required and must be a nonblank string.
Author (author) is required and must be a nonblank string.
```

The unchanged exporter uses `ThemePackageManifestSchema`,
`calculateThemeAssetHash`, `calculateThemePackageDigest` and
`validateThemePackageAssets`. Canonical manifest SHA-256 (`assetsDigest`) is
different from ZIP SHA-256 in the outer integrity inventory. ZIP export allows
only declared media, not JavaScript/TypeScript. Engine import additionally
checks ZIP safety, actual media bytes, registered code/version compatibility
and atomic installation. Existing installed legacy themes do not acquire a
new runtime credits requirement.
## Complete-game import

The public Theme SDK 0.2.0 exposes the version-1 campaign schema and the
Node-only `@multiplayer-game/theme-sdk/package` manifest validator. The
Developer Kit's `GAME-PACKAGE.md` defines the package, trust, server import and
Studio export boundaries; the versioned campaign ZIP under `fixtures/` is
validated by the kit verification process, not by the local preview.
