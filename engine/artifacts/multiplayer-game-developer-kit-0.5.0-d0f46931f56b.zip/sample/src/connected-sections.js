/* Theme Credits (generated)
 * Project: Local Preview Sample
 * Author: Scott Zastrow
 * Description: Public consumer example for connected-section movement.
 * End Theme Credits
 */
import {
  qualifyConnectedMapReference,
  validateConnectedMapDefinition
} from "@multiplayer-game/theme-sdk";

function sectionMap(startId, startX, wallX) {
  const wallId = "wall";
  return {
    bounds: { width: 2_048, height: 256 },
    cellSize: 32,
    objects: [
      { id: wallId, typeId: "wall", position: { x: wallX, y: 128 } }
    ],
    collisions: [
      {
        id: "wall-collision",
        objectId: wallId,
        shape: { type: "rect", width: 32, height: 64 }
      }
    ],
    spawns: [
      {
        id: startId,
        kind: "player",
        position: { x: startX, y: 80 },
        radius: 8
      }
    ]
  };
}

export const connectedSectionsMap = validateConnectedMapDefinition({
  formatVersion: 1,
  id: "connected-sections-example",
  name: "Connected Sections",
  cellSize: 32,
  sections: [
    {
      id: "west",
      origin: { x: -2_048, y: 0 },
      map: sectionMap("player-start", 2_032, 512)
    },
    {
      id: "east",
      origin: { x: 0, y: 0 },
      map: sectionMap("player-start", 16, 1_536)
    }
  ]
});

export const connectedSectionsGameModule = Object.freeze({
  metadata: Object.freeze({
    id: "connected-sections-example",
    version: "1.0.0",
    stateSchemaVersion: 1
  }),

  validateSettings(settings) {
    return typeof settings === "object" && settings !== null;
  },

  create(context, _settings, roster) {
    if (!context.connectedMap) {
      throw new TypeError("The connected-sections example requires a connected world.");
    }
    const starts = context.connectedMapSpawns
      ?.filter(spawn => spawn.kind === "player")
      ?? [];
    const movement = new Map(roster.map(player => [player.accountId, { x: 0, y: 0 }]));
    let tick = 0;

    return {
      stateSchemaVersion: 1,
      initialize() {
        if (starts.length < roster.length) {
          throw new TypeError("The connected world has too few player starts.");
        }
        for (const [index, player] of roster.entries()) {
          const spawn = starts[index];
          if (!spawn) throw new Error("The connected world player-start lookup failed.");
          context.entities.add({
            id: `player:${player.accountId}`,
            typeId: "connected-player",
            position: spawn.position,
            radius: spawn.radius,
            state: {
              accountId: player.accountId,
              startId: spawn.id,
              qualifiedStartId: qualifyConnectedMapReference(spawn.sectionId, spawn.id)
            }
          });
        }
      },
      validateInput(input) {
        return typeof input === "object" && input !== null &&
          [input.x, input.y].every(value =>
            Number.isFinite(value) && Math.abs(value) <= 4_096
          );
      },
      applyInput(accountId, input) {
        movement.set(accountId, { x: input.x, y: input.y });
      },
      step(_dtSeconds, nextTick) {
        tick = nextTick;
        for (const entity of context.entities.values()) {
          const intent = movement.get(entity.state.accountId);
          if (!intent) continue;
          const position = context.geometry.moveCircle(
            entity.position,
            intent,
            entity.radius
          );
          context.entities.update(entity.id, current => ({ ...current, position }));
        }
      },
      snapshot() {
        return {
          tick,
          players: context.entities.values().map(entity => ({
            accountId: entity.state.accountId,
            position: entity.position,
            startId: entity.state.startId,
            qualifiedStartId: entity.state.qualifiedStartId
          }))
        };
      },
      results() {
        return { tick };
      },
      dispose() {
        movement.clear();
      }
    };
  }
});
