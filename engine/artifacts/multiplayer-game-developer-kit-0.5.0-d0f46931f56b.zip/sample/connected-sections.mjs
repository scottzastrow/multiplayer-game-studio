import assert from "node:assert/strict";
import { createLocalGame } from "@multiplayer-game/local-preview";
import {
  connectedSectionsGameModule,
  connectedSectionsMap
} from "./src/connected-sections.js";

const roster = [
  { accountId: "west-player", username: "West Player", joinedOrder: 0 },
  { accountId: "east-player", username: "East Player", joinedOrder: 1 }
];
const game = await createLocalGame({
  moduleFactory: connectedSectionsGameModule,
  settings: {},
  world: connectedSectionsMap,
  seed: 42,
  roster,
  viewer: { accountId: "west-player", role: "player" }
});

try {
  const west = game.snapshot.players.find(player => player.accountId === "west-player");
  const east = game.snapshot.players.find(player => player.accountId === "east-player");
  assert.ok(west && east);
  assert.equal(west.position.x, -16);
  assert.equal(east.position.x, 16);
  game.sendInput("west-player", { x: 64, y: 0 });
  game.sendInput("east-player", { x: -64, y: 0 });
  game.step();
  assert.equal(game.snapshot.players.find(player =>
    player.accountId === "west-player")?.position.x, 48);
  assert.equal(game.snapshot.players.find(player =>
    player.accountId === "east-player")?.position.x, -48);
  console.log("Public connected-section consumer passed: west→east and east→west crossings.");
} finally {
  game.dispose();
}
