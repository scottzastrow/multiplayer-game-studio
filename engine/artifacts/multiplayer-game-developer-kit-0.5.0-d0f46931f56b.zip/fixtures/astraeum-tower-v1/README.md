# Astraeum campaign import fixture

This deterministic two-level, two-section campaign exercises the registered
Astraeum adapter, safe starts, shared combat, automatic chest rewards,
connected-section traversal, and sequential rune progression. Its 1x1
generated art is only for contract/import checks, not a visual acceptance test
or a Studio export.
