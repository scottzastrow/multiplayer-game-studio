# Versioned complete-game packages

The existing credited media-only theme ZIP remains valid. A complete-game ZIP
extends that family; it is not an editor backup or a JavaScript bundle. Its root
contains `theme.json`, `campaign.json`, and every declared required media file.
Optional media may be omitted. All entries use the existing ZIP path, archive,
media, and extraction limits.

`theme.json` keeps the existing theme, exact module/skin versions, Engine API
major, settings schema/defaults, Project/Author credits and media asset maps.
It additionally declares:

```json
{
  "gamePackage": {
    "schemaVersion": 1,
    "sdkVersion": "0.3.0",
    "adapter": { "id": "dots-and-squares", "version": "1.0.0" },
    "campaign": {
      "path": "campaign.json",
      "sha256": "<lowercase SHA-256 of exact campaign.json bytes>"
    }
  }
}
```

The complete manifest is validated by
`GamePackageManifestSchema` from `@multiplayer-game/theme-sdk/package`.
`assetsDigest` is still the canonical hash of the complete manifest excluding
only `assetsDigest`; it therefore binds credits, the campaign hash, adapter
version and all required/optional media hashes. `campaign.json` is a separately
declared payload, not a media asset. Its 8 MiB limit is in addition to the
existing 10 MiB archive, 40 MiB extracted, 256-entry and media bounds.

`campaign.json` is strict `GameCampaignSchema` version 1:

- `startingLevelId` and `startingSectionId` identify the initial server map.
- `levels[]` contains stable IDs, names, a version-1 connected map with active
  sections, signed world origins, local objects/collisions and authored starts.
- Each level owns its world `boundary`, camera anchor/zoom and exits. Boundary
  and camera data stays at level scope even when Studio's original boundary
  owner section was archived.
- Each exit identifies its active source section/object and destination
  `levelId`, `sectionId` and player `startId`.
- `settings` is a JSON object interpreted only by the registered adapter.

Validation checks map and aggregate budgets, unique IDs, root boundaries,
navigation-grid alignment, safe player starts against collision geometry,
the designated starting section, exit source objects, and every destination
against an active safe player start. Dangling, archived, missing and blocked
destinations are rejected before promotion. The campaign document, required
media bytes, credits and adapter compatibility are all validated before the
registry transaction. Promotion is rolled back if database registration fails.
Existing revisions and their files remain unchanged on rejection.

## Trust and current server behavior

The registered adapters are `dots-and-squares@1.0.0` and
`astraeum-tower@1.0.0`. Astraeum binds the compiled
`astraeum-tower@1.0.0` module, state schema 1 and
`astraeum-tower-skin@1.0.0` renderer. It accepts only `playerSpeed: 2`,
sequential level exits and the Astraeum campaign object/media rules. Its
authoritative module owns combat, shared loot/inventory, automatic chests and
pickups, and rune-triggered progression; the shared rules are documented in
[`astraeum-multiplayer.md`](astraeum-multiplayer.md). The initial level and
section are converted to the authoritative map and the validated campaign is
supplied through `ModuleContext.campaign`. Import contains only JSON and media;
unregistered adapters, modules and renderers get actionable compatibility
errors. Uploaded JavaScript, TypeScript, HTML, SVG or other executable content
is never accepted or evaluated.

The existing operator-only `/api/v1/admin/themes/upload` endpoint installs the
package. The server registers the revision in the running process and reloads
persisted package manifests/assets against the compiled registries on startup.
The multiplayer lifecycle therefore initializes the registered server module
from an imported package; a local preview or importer-only test is not used as
that proof.

Authenticated clients can read a revision manifest from
`GET /api/v1/themes/:themeId/:version?digest=<sha256>` and fetch declared media
from `GET /api/v1/themes/:themeId/:version/assets/:assetId?digest=<sha256>`.
Both endpoints require the pinned digest; asset responses are re-hashed against
the installed declaration before serving and use immutable private caching.
Unknown revisions/assets return 404, while a digest mismatch returns an
actionable 409 compatibility error. The browser resolves imported revision
media through this digest-pinned API using the registered client skin.

`SessionLifecycle` starts Astraeum with the package campaign's connected-world
geometry and uses the named destination section/start for authoritative
transitions. The browser uses its compiled, registered skin and resolves
package media through the digest-pinned Engine asset API. Package ZIPs still
cannot upload executable code; only code already reviewed and registered in
the Engine build is runnable.

## Custom game code is a separate Engine build

Custom code is not made importable by placing it in the ZIP. A game owner must
submit source and provenance to the Engine owner; the reviewed code is compiled
into Engine-owned server and client artifacts, its exact module/skin/state
versions are added to both explicit registries, and a versioned server-side
campaign adapter is registered against that module. Add module-level,
server-lifecycle and client/skin conformance tests before building the public
SDK/Engine packages. The independent consumer fixture must compile against the
published SDK without private Engine imports. Only after that reviewed build is
available may a ZIP reference those exact registrations. The Astraeum
integration is a compiled, reviewed exception to this custom-code workflow;
arbitrary game code remains unsupported.

## Exact Studio Export Game requirements

Studio must implement Export Game as a saved-project snapshot, not an editor
backup, Vite bundle or Play-state capture:

1. Show Export Game only in Edit mode. Resolve pending gestures and uncertain
   saves first. If drafts are dirty, offer Save then export or Cancel. Never
   silently include unsaved edits or discard them; failed or conflicting saves
   block export and retain their visible error.
2. Read project identity/confirmed credits, designated start, active independent
   levels, active sections, revisions, settings, catalog references and
   allowlisted asset bytes/hashes in one SQLite read transaction. Abort on a
   missing or changed asset rather than mixing revisions or producing a partial
   ZIP. Use `levelList`/`levelSectionPayload` semantics, never
   `project.json.mapIds` or a sequence of unguarded per-level HTTP calls.
3. Export only active level/section content. Preserve level-root boundary and
   camera metadata even if its owner section was archived, but omit that
   section's objects/documents. Exclude deleted levels, archived sections, old
   World records, databases/WAL/backups/recovery files, secrets, dependencies,
   installed kits, diagnostics, unrelated files and Play-run state. Use an
   explicit file allowlist; never ZIP a directory recursively.
4. Validate model/document versions, project and public credits, section/world
   capacities, boundaries, safe starts, settings, required media and code
   dependency closure. Resolve every exit within the same active campaign to an
   active section and unique safe player start using the shared headless
   geometry/exit validation, not browser Play. Reject dangling, deleted,
   archived, cross-project or blocked destinations before writing ZIP bytes.
   Include module-required artwork as well as placed palette assets and preserve
   authored properties such as chest tier.
5. Export the exact Engine package contract above. Do not include executable
   source; reference only reviewed, registered, compatible modules/adapters/
   skins. Keep reusable Studio integration under `studio/extensions/`, adapt
   game-specific controllers under `games/<game>/`, and install only an
   authorized versioned kit.
6. Report errors with the affected level, section, object or asset. Do not
   offer a downloadable complete game until the exact ZIP has passed Engine
   import and server initialization.
